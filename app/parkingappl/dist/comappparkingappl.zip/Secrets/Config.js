sap.ui.define([],function(){"use strict";return{twilio:{fromNumber:"+15856485867"}}});
//# sourceMappingURL=Config.js.map