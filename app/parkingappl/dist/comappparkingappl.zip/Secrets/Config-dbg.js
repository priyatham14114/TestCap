
sap.ui.define([], function() {
    "use strict";
    return {
        twilio: {
            // accountSid: '',
            // authToken: '',
            fromNumber: '+15856485867'
        }
    };
});